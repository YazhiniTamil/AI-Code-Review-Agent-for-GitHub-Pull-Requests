import hashlib, hmac, secrets, base64
from cryptography.fernet import Fernet, InvalidToken
from fastapi import HTTPException, Request
from app.core.config import settings

def _fernet():
    if not settings.app_encryption_key: raise RuntimeError("APP_ENCRYPTION_KEY is required to connect repositories")
    try: return Fernet(settings.app_encryption_key.encode())
    except Exception as exc: raise RuntimeError("APP_ENCRYPTION_KEY must be a valid Fernet key") from exc

def encrypt_token(token: str) -> str: return _fernet().encrypt(token.encode()).decode()
def decrypt_token(value: str) -> str:
    try: return _fernet().decrypt(value.encode()).decode()
    except (InvalidToken, ValueError) as exc: raise RuntimeError("Stored GitHub token cannot be decrypted; verify APP_ENCRYPTION_KEY") from exc

def valid_signature(body: bytes, supplied: str, secret: str) -> bool:
    if not secret or not supplied.startswith("sha256="): return False
    digest = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    return hmac.compare_digest("sha256=" + digest, supplied)

async def require_dashboard_auth(request: Request):
    user, password = settings.dashboard_username, settings.dashboard_password
    if not user and not password: return
    auth = request.headers.get("authorization", "")
    try:
        scheme, encoded = auth.split(" ", 1)
        got_user, got_pass = base64.b64decode(encoded, validate=True).decode().split(":", 1)
    except Exception:
        scheme = got_user = got_pass = ""
    if scheme.lower() != "basic" or not (secrets.compare_digest(got_user, user) and secrets.compare_digest(got_pass, password)):
        raise HTTPException(status_code=401, detail="Authentication required", headers={"WWW-Authenticate": "Basic"})
