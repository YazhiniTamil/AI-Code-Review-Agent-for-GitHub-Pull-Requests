import json, logging, re
from fastapi import APIRouter, Depends, HTTPException, Request, BackgroundTasks, Query
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from sqlalchemy import desc
from app.db.database import get_db
from app.db.models import Repository, Review, Delivery
from app.core.security import encrypt_token, valid_signature
from app.core.config import settings
from app.services.github import GitHubClient, GitHubError
from app.services.reviewer import run_review
log=logging.getLogger(__name__); router=APIRouter(prefix="/api")
class RepoCreate(BaseModel): full_name:str=Field(min_length=3,max_length=250); token:str=Field(min_length=10)
class ReviewRequest(BaseModel): pr_number:int=Field(gt=0)
def review_dict(r): return {"id":r.id,"repository":r.repository.full_name,"pr_number":r.pr_number,"title":r.title,"url":r.url,"status":r.status,"findings":json.loads(r.findings_json or "[]"),"error":r.error,"created_at":r.created_at.isoformat() if r.created_at else None}
@router.get("/health")
def health(): return {"status":"ok"}
@router.get("/repositories")
def list_repositories(db:Session=Depends(get_db)): return [{"id":r.id,"full_name":r.full_name,"created_at":r.created_at.isoformat()} for r in db.query(Repository).order_by(Repository.full_name).all()]
@router.post("/repositories",status_code=201)
def create_repository(body:RepoCreate,db:Session=Depends(get_db)):
    name=body.full_name.strip().strip("/")
    if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+",name): raise HTTPException(400,"Use owner/repository format")
    try: encrypted=encrypt_token(body.token)
    except RuntimeError as e: raise HTTPException(503,str(e))
    existing=db.query(Repository).filter_by(full_name=name).first()
    if existing: existing.token_ciphertext=encrypted; db.commit(); return {"id":existing.id,"full_name":name,"updated":True}
    repo=Repository(full_name=name,token_ciphertext=encrypted); db.add(repo); db.commit(); db.refresh(repo)
    return {"id":repo.id,"full_name":name,"created":True}
@router.delete("/repositories/{repo_id}")
def delete_repository(repo_id:int,db:Session=Depends(get_db)):
    repo=db.get(Repository,repo_id)
    if not repo: raise HTTPException(404,"Repository not found")
    db.delete(repo); db.commit(); return {"deleted":True}
@router.get("/reviews")
def list_reviews(q:str|None=None,status:str|None=None,limit:int=Query(50,ge=1,le=200),offset:int=0,db:Session=Depends(get_db)):
    query=db.query(Review).join(Repository)
    if q: query=query.filter((Repository.full_name.ilike(f"%{q}%"))|(Review.title.ilike(f"%{q}%"))|(Review.pr_number==int(q) if q.isdigit() else False))
    if status: query=query.filter(Review.status==status)
    return {"items":[review_dict(r) for r in query.order_by(desc(Review.created_at)).offset(offset).limit(limit).all()]}
@router.post("/repositories/{repo_id}/reviews",status_code=202)
def trigger_review(repo_id:int,body:ReviewRequest,bg:BackgroundTasks,db:Session=Depends(get_db)):
    repo=db.get(Repository,repo_id)
    if not repo: raise HTTPException(404,"Repository not found")
    review=Review(repository_id=repo.id,pr_number=body.pr_number,status="queued"); db.add(review); db.commit(); db.refresh(review)
    bg.add_task(run_review,review.id); return {"id":review.id,"status":"queued"}
@router.post("/reviews/{review_id}/retry",status_code=202)
def retry_review(review_id:int,bg:BackgroundTasks,db:Session=Depends(get_db)):
    r=db.get(Review,review_id)
    if not r: raise HTTPException(404,"Review not found")
    if r.status not in ("failed","completed"): raise HTTPException(409,"Only failed or completed reviews can be retried")
    r.status="queued"; r.error=None; db.commit(); bg.add_task(run_review,r.id); return {"id":r.id,"status":"queued"}
@router.post("/webhooks/github")
async def github_webhook(request:Request,bg:BackgroundTasks,db:Session=Depends(get_db)):
    raw=await request.body()
    if not valid_signature(raw,request.headers.get("x-hub-signature-256",""),settings.github_webhook_secret): raise HTTPException(401,"Invalid webhook signature")
    delivery_id=request.headers.get("x-github-delivery")
    if not delivery_id: raise HTTPException(400,"Missing X-GitHub-Delivery")
    if db.query(Delivery).filter_by(delivery_id=delivery_id).first(): return {"status":"duplicate"}
    try: event=json.loads(raw)
    except ValueError: raise HTTPException(400,"Malformed JSON")
    db.add(Delivery(delivery_id=delivery_id)); db.commit()
    if request.headers.get("x-github-event")!="pull_request": return {"status":"ignored"}
    action=event.get("action")
    if action not in ("opened","synchronize","reopened","ready_for_review"): return {"status":"ignored"}
    pr=event.get("pull_request") or {}; number=pr.get("number"); full_name=(event.get("repository") or {}).get("full_name")
    repo=db.query(Repository).filter_by(full_name=full_name).first()
    if repo and isinstance(number,int):
        r=Review(repository_id=repo.id,pr_number=number,title=pr.get("title","")[:500],url=pr.get("html_url", ""),status="queued")
        db.add(r); db.commit(); db.refresh(r); bg.add_task(run_review,r.id); return {"status":"accepted","review_id":r.id}
    return {"status":"unregistered repository"}
