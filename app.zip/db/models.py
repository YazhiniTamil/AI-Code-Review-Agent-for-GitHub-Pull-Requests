from datetime import datetime, timezone
from sqlalchemy import String, Integer, DateTime, Text, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.database import Base
def now(): return datetime.now(timezone.utc)
class Repository(Base):
    __tablename__="repositories"
    id: Mapped[int]=mapped_column(Integer,primary_key=True)
    full_name: Mapped[str]=mapped_column(String(250),unique=True,index=True)
    token_ciphertext: Mapped[str]=mapped_column(Text)
    webhook_id: Mapped[str|None]=mapped_column(String(200),nullable=True)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
    reviews: Mapped[list["Review"]]=relationship(back_populates="repository",cascade="all, delete-orphan")
class Review(Base):
    __tablename__="reviews"
    id: Mapped[int]=mapped_column(Integer,primary_key=True)
    repository_id: Mapped[int]=mapped_column(ForeignKey("repositories.id"),index=True)
    pr_number: Mapped[int]=mapped_column(Integer,index=True)
    title: Mapped[str]=mapped_column(String(500),default="")
    url: Mapped[str]=mapped_column(Text,default="")
    status: Mapped[str]=mapped_column(String(30),default="queued",index=True)
    findings_json: Mapped[str]=mapped_column(Text,default="[]")
    error: Mapped[str|None]=mapped_column(Text,nullable=True)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now,index=True)
    updated_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now,onupdate=now)
    repository: Mapped[Repository]=relationship(back_populates="reviews")
class Delivery(Base):
    __tablename__="deliveries"
    id: Mapped[int]=mapped_column(Integer,primary_key=True)
    delivery_id: Mapped[str]=mapped_column(String(200),unique=True,index=True)
    received_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
