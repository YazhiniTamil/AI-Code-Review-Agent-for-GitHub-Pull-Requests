from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker
from app.core.config import settings
connect_args={"check_same_thread":False} if settings.database_url.startswith("sqlite") else {}
engine=create_engine(settings.database_url,connect_args=connect_args,future=True)
SessionLocal=sessionmaker(bind=engine,autoflush=False,expire_on_commit=False)
class Base(DeclarativeBase): pass
def get_db():
    db=SessionLocal()
    try: yield db
    finally: db.close()
def init_db():
    from app.db import models
    if settings.database_url.startswith("sqlite"):
        from pathlib import Path
        path=settings.database_url.replace("sqlite:///","",1)
        if path != ":memory:": Path(path).parent.mkdir(parents=True,exist_ok=True)
    Base.metadata.create_all(bind=engine)
