from pathlib import Path
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from app.core.logging import configure_logging
from app.core.security import require_dashboard_auth
from app.db.database import init_db
from app.api.routes import router

configure_logging()

@asynccontextmanager
async def lifespan(app):
    init_db()
    yield

app = FastAPI(title="AI Code Review Agent for GitHub Pull Requests", version="1.0.0", lifespan=lifespan)
app.include_router(router)
static = Path(__file__).parent / "static"
app.mount("/static", StaticFiles(directory=static), name="static")

@app.middleware("http")
async def dashboard_authentication(request: Request, call_next):
    # GitHub authenticates this endpoint independently using the signed raw body.
    if request.url.path != "/api/webhooks/github":
        try:
            await require_dashboard_auth(request)
        except HTTPException as exc:
            return JSONResponse({"detail": exc.detail}, status_code=exc.status_code, headers=exc.headers)
    return await call_next(request)

@app.get("/", include_in_schema=False)
def index():
    return FileResponse(static / "index.html")
