from pydantic import BaseModel, Field, ValidationError
from openai import OpenAI, APIError, APITimeoutError, RateLimitError
from app.core.config import settings
class Finding(BaseModel):
    path: str
    line: int=Field(ge=1)
    severity: str
    category: str
    title: str
    body: str
class ReviewOutput(BaseModel):
    summary: str
    findings: list[Finding]
FUNCTION={"type":"function","function":{"name":"submit_review","description":"Submit actionable findings supported by the diff.","parameters":{"type":"object","properties":{"summary":{"type":"string"},"findings":{"type":"array","items":{"type":"object","properties":{"path":{"type":"string"},"line":{"type":"integer","minimum":1},"severity":{"type":"string","enum":["critical","high","medium","low","info"]},"category":{"type":"string","enum":["bug","security","missing_test","quality","improvement"]},"title":{"type":"string","maxLength":120},"body":{"type":"string","maxLength":1500}},"required":["path","line","severity","category","title","body"],"additionalProperties":False}}},"required":["summary","findings"],"additionalProperties":False}}}
def analyze(files):
    if not settings.openai_api_key: raise RuntimeError("OPENAI_API_KEY is not configured")
    client=OpenAI(api_key=settings.openai_api_key,timeout=45,max_retries=2)
    diff="\n".join(f"FILE: {f.get('filename')}\nSTATUS: {f.get('status')}\nPATCH:\n{(f.get('patch') or '[diff omitted by GitHub]').strip()}" for f in files)[:60000]
    try:
        response=client.chat.completions.create(model=settings.openai_model,messages=[{"role":"system","content":"You are a careful senior code reviewer. Review only changed lines in supplied GitHub diffs. Identify concrete bugs, security vulnerabilities, missing tests, code quality issues, and improvements. Avoid nitpicks and unsupported claims. Use exact changed-file paths and new-file line numbers; findings must be actionable. Return an empty findings list if appropriate."},{"role":"user","content":"Review this pull request diff:\n\n"+diff}],tools=[FUNCTION],tool_choice={"type":"function","function":{"name":"submit_review"}},temperature=0.1)
    except (APITimeoutError,RateLimitError,APIError) as exc: raise RuntimeError(f"OpenAI request failed: {type(exc).__name__}") from exc
    calls=response.choices[0].message.tool_calls
    if not calls: raise RuntimeError("OpenAI response did not include the required review function call")
    try: return ReviewOutput.model_validate_json(calls[0].function.arguments)
    except (ValidationError,ValueError) as exc: raise RuntimeError("OpenAI returned invalid review findings") from exc
