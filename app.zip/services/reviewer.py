import json, logging, re
from app.db.database import SessionLocal
from app.db.models import Review, Repository
from app.core.security import decrypt_token
from app.services.github import GitHubClient
from app.services.analyzer import analyze

log = logging.getLogger(__name__)
_HUNK = re.compile(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@")

def changed_lines(files):
    """Return file path -> new-side line numbers represented by GitHub diff hunks."""
    allowed = {}
    for file in files:
        path, patch = file.get("filename"), file.get("patch") or ""
        if not path: continue
        lines = set(); current = None
        for row in patch.splitlines():
            match = _HUNK.search(row)
            if match:
                current = int(match.group(3))
                continue
            if current is None or row.startswith("\\"): continue
            if row.startswith("+"):
                lines.add(current); current += 1
            elif row.startswith("-"):
                continue
            else:
                lines.add(current); current += 1
        allowed[path] = lines
    return allowed

def run_review(review_id):
    db = SessionLocal(); gh = None; review = None
    try:
        review = db.get(Review, review_id)
        if review is None: return
        repo = db.get(Repository, review.repository_id)
        if repo is None: raise RuntimeError("Repository no longer exists")
        review.status = "running"; review.error = None; db.commit()
        gh = GitHubClient(decrypt_token(repo.token_ciphertext))
        pr = gh.pull_request(repo.full_name, review.pr_number); files = gh.files(repo.full_name, review.pr_number)
        review.title = pr.get("title", "")[:500]; review.url = pr.get("html_url", "")
        result = analyze(files); valid_lines = changed_lines(files); findings = []
        for finding in result.findings:
            item = finding.model_dump()
            if item["line"] in valid_lines.get(item["path"], set()): findings.append(item)
        comments = [{"path": f["path"], "line": f["line"], "body": f"**{f['severity'].upper()} · {f['category'].replace('_', ' ')} — {f['title']}**\n\n{f['body']}"} for f in findings]
        # Save usable findings before publishing so publication errors preserve inspectable history.
        review.findings_json = json.dumps(findings); db.commit()
        gh.post_review(repo.full_name, review.pr_number, "AI Code Review\n\n" + result.summary, comments)
        review.status = "completed"; review.error = None; db.commit()
    except Exception as exc:
        log.exception("Review %s failed (%s)", review_id, type(exc).__name__)
        if review is not None:
            try:
                review.status = "failed"; review.error = f"{type(exc).__name__}: {str(exc)[:500]}"; db.commit()
            except Exception:
                db.rollback(); log.exception("Unable to persist failed state for review %s", review_id)
    finally:
        if gh: gh.close()
        db.close()
