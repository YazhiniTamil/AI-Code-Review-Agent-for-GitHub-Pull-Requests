import httpx
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

class GitHubError(Exception): pass
_TRANSIENT = (httpx.TimeoutException, httpx.NetworkError, httpx.HTTPStatusError)

class GitHubClient:
    def __init__(self, token):
        self.client = httpx.Client(base_url="https://api.github.com", headers={"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28"}, timeout=30)

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(min=0.05, max=0.2), retry=retry_if_exception_type(_TRANSIENT), reraise=True)
    def _get(self, path, params=None):
        r = self.client.get(path, params=params)
        if r.status_code >= 500: raise httpx.HTTPStatusError("GitHub server error", request=r.request, response=r)
        if r.is_error: raise GitHubError(f"GitHub API returned {r.status_code}: {r.text[:300]}")
        return r

    def pull_request(self, repo, number): return self._get(f"/repos/{repo}/pulls/{number}").json()
    def files(self, repo, number):
        result = []; page = 1
        while True:
            batch = self._get(f"/repos/{repo}/pulls/{number}/files", {"per_page": 100, "page": page}).json()
            result.extend(batch)
            if len(batch) < 100: return result
            page += 1

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(min=0.05, max=0.2), retry=retry_if_exception_type(_TRANSIENT), reraise=True)
    def post_review(self, repo, number, body, comments):
        payload = {"body": body, "event": "COMMENT"}
        if comments: payload["comments"] = comments
        r = self.client.post(f"/repos/{repo}/pulls/{number}/reviews", json=payload)
        if r.status_code >= 500: raise httpx.HTTPStatusError("GitHub server error", request=r.request, response=r)
        if r.is_error: raise GitHubError(f"Could not publish review ({r.status_code}): {r.text[:300]}")
        return r.json()

    def close(self): self.client.close()
